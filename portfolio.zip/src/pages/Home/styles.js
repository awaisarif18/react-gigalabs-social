import { motion } from "framer-motion";
import styled from "styled-components";

export const HomeSection = styled(motion.div)`
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  /* overflow-x: hidden; */
`;
