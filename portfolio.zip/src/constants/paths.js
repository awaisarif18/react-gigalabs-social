export const paths = {
  root: "/",
  home: "/",
  SignUp: "/signup",
  ChangePassword: "/changepassword",
  login: "/login",
  Employees: "/employees",
  OneEmployee: "/employee/:id",
};
