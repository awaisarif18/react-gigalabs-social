import styled from "styled-components";

export const Root = styled.div`
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  background-color: aliceblue;
  /* outline: 1px solid red; */
  /* display: grid;
  grid-template-columns: 1fr; */
  /* overflow-y: hidden; */
`;
