import styled from "styled-components";

export const StyledLayout = styled.div`
  /* margin: 0;
  padding: 0;
  box-sizing: border-box; */

  /* display: flex;
  flex-direction: column; */
`;
