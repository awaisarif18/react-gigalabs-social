import styled from "styled-components";

export const StyledParagraph = styled.div`
  height: 20vh;
  font-size: 1.6rem;
  font-family: "Fraunces", serif;
`;
