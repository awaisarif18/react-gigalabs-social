import styled from "styled-components";

export const StyledHeading2 = styled.h2`
  font-size: 3 rem;
  font-weight: lighter;
  font-family: "Poppins", sans-serif;
`;
